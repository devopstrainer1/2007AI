### importing langchain and other libraries

### please add prompt template logic --- assignment 1
### please try to use gradio in place of streamlit --- assignment 2

from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter ### chunkking
from langchain_google_genai import ChatGoogleGenerativeAI ###LLM
from langchain_community.embeddings import HuggingFaceEmbeddings ### embedding model
from langchain_classic.chains import RetrievalQA ### RAG framework
from langchain_chroma import Chroma ### vector database
from langchain_classic.prompts import PromptTemplate ### prompt template
from langchain_community.retrievers import BM25Retriever ### BM25 sparse retrieval
from langchain_classic.retrievers import EnsembleRetriever

### import basic libraries

import os
import streamlit as st
from dotenv import load_dotenv

### load environment variables from .env file
load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

## error handling scenarios for missing API key
if not GOOGLE_API_KEY:
    st.error("GOOGLE_API_KEY is not set in the environment variables.")
    st.stop()

os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

### set up streamlit UI

st.set_page_config(page_title="Hybrid RAG", page_icon=":robot_face:", layout="wide")

st.title("Hybrid RAG: Combining BM25 and Embeddings for Document Retrieval")

st.caption("Upload a PDF document and ask questions about its content.")


### upload file logic

uploaded_file = st.file_uploader("Upload a PDF file", type=["pdf"])

## initialize docs

docs = None

if uploaded_file:
    #### use a temporary file to save the uploaded PDF
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as temp_file:
        temp_file.write(uploaded_file.read())
        temp_file_path = temp_file.name

#### load the PDF document using PyPDFLoader
    loader = PyPDFLoader(temp_file_path)
    documents = loader.load()

    ### chunking technique
    text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=150
)

    docs = text_splitter.split_documents(documents)


### step 5 - create embedding & vector store

### 384 dimensions

    embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

    vectorstore = Chroma.from_documents(
    docs,
    embeddings,
    collection_name="hr_policy"
)

    ### sparse retrieval

    bm25_retriever = BM25Retriever.from_documents(docs)
    bm25_retriever.k = 8

    ### dense retrieval technique...
    dense_retriever = vectorstore.as_retriever(search_kwargs={"k": 8})

    ### hybrid rag

    retriever = EnsembleRetriever(
        retrievers=[bm25_retriever, dense_retriever],
        weights=[0.4, 0.6]
    )

    ### call llm
    llm = ChatGoogleGenerativeAI(model="gemini-flash-latest", temperature=0.2)

    qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff", ### map_reduce, refine
    retriever=retriever
    )

    ### streamlit UI for input and output box

    query = st.text_input("Ask a question about the document:")

    if st.button("Get Answer") and query:
        with st.spinner("Generating answer..."):
            try:
                response = qa_chain.run(query)
                st.success("Answer generated!")
                st.write(response['result'])
            except Exception as e:
                st.error(f"Error generating answer: {e}")
    else:
        st.info("Please enter a question and click 'Get Answer' to retrieve the answer.")

else:
    st.info("Please upload a PDF document to start.")
