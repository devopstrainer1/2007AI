#### execution steps

1> create virtual environment

python -m venv venv

source venv/bin/activate ( mac)

venv\scripts\activate( windows)

2> install packages

pip install -r requirements.txt

3> run the app logic file

python -m streamlit run amit.py