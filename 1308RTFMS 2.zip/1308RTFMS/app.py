### import libraries
### assignment is add reset functionality as a column
import streamlit as st
import os
import pandas as pd
import time
import random
import re  ## for regular expressions

from langgraph.graph import StateGraph ### nodes & edges
from langgraph.graph import END #### nodes to mark end of workflow/terminate
from langchain_groq import ChatGroq ### LLM Library
from typing import TypedDict, List, Dict, Any 


### UI Config


st.set_page_config(
    page_title="LangGraph RTFMS",
    page_icon=":robot:",
    layout="wide",
)

### LLM setup

os.environ["GROQ_API_KEY"] = "gsk_jSWMWQf5ylXZ6ZvK468iQji"

llm = ChatGroq(
    model_name="openai/gpt-oss-120b",
    groq_api_key=os.environ["GROQ_API_KEY"],
    temperature=0.7,
)

def ask_llm(prompt):
    return llm.invoke(prompt).content

#### state

class BotState(TypedDict, total=False):
    user_input: str
    transactions: List[Dict[str, Any]]
    amount: float
    risk: str
    fraud_score: float
    alert: str


### define regex to extract amount from transaction description

def parse_amount(text):
    match = re.search(r"\d+(?:,\d+)*(?:\.\d+)?", text)
    return float(match.group()) if match else 0


#### define risk assessment function

def compute_fraud_score(text, amount, history):
    score = 0

    if amount > 100000:
        score += 30
    elif amount > 50000:
        score += 20
    elif amount > 10000:
        score += 10

    if any(keyword in text.lower() for keyword in ["suspicious", "fraud", "unauthorized", "offshore", "crypto"]):
        score += 40
    
    if len(history) ==0:
        score += 10

    if len(history) > 5:
        score += 5

    return min(score, 100)


def get_risk(score):
    if score >= 70:
        return "HIGH"
    elif score >= 40:
        return "MEDIUM"
    else:
        return "LOW"
    

def generate_txn():
    samples = [
        "Transfer of $5000 to offshore account",
        "Payment of $20000",
        "Suspicious transaction of $150000 detected",
        "Unauthorized withdrawal of $3000 from account",
        "Crypto purchase of $25000",
        "Transfer $1000"
    ]
    return random.choice(samples)
    


### langgraph nodes

### node 1: process transaction

def node_process(state: BotState) -> BotState:
    text = state["user_input"]
    history = state.get("transactions", [])

    ### use above function to parse amount
    amount = parse_amount(text)
    score = compute_fraud_score(text, amount, history)
    risk = get_risk(score)

    ### update state
    state["amount"] = amount
    state["risk"] = risk
    state["fraud_score"] = score

   
    return state

### node2 : HITL

def node_hitl(state: BotState) -> BotState:
    state["alert"] = " Escalated to human fraud review"
    return state

### route

def route(state: BotState):
    if state["risk"] == "HIGH":
        return "hitl"
    return "end"


### build graph

builder = StateGraph(BotState)

builder.add_node("process", node_process)
builder.add_node("hitl", node_hitl)

###error
builder.set_entry_point("process")

### adding conditional edges

builder.add_conditional_edges(
    "process",
    route,
    {
        "hitl": "hitl",
        "end": END
    }
)

graph = builder.compile()

### session state

if "transactions" not in st.session_state:
    st.session_state.transactions = []

if "explanations" not in st.session_state:
    st.session_state.explanations = {}

#### UI Header

st.title("Real time Payment fraud monitoring")

col1, col2, col3 = st.columns(3)

txns = st.session_state.transactions

total_volume = sum(t["amount"] for t in txns) if txns else 0
high_risk = sum(1 for t in txns if t["risk"] == "HIGH")
medium_risk = sum(1 for t in txns if t["risk"] == "MEDIUM")


col1.metric("Total Volume", f"{int(total_volume):,}")

col2.metric("🔴 High Risk", high_risk)
col3.metric("🟡 Medium Risk", medium_risk)


### toggle stream control

run = st.toggle("Start Live Stream")


## define logic for real time stream

if run:
    for _ in range(10):

        msg = generate_txn()

        ### call langgraph state class

        state = {
            "user_input": msg,
            "transactions": st.session_state.transactions
        }

        state = graph.invoke(state)

        txn = {
            "id": len(st.session_state.transactions),
            "text": msg,
            "amount": state["amount"],
            "score": state["fraud_score"],
            "risk": state["risk"]
        }

        st.session_state.transactions.append(txn)

        time.sleep(1)


### UI to display transactions

st.subheader("Live Transactions")

for txn in st.session_state.transactions:
    color = {
        "HIGH": "🔴", 
        "MEDIUM": "🟡",
        "LOW": "🟢"
    }[txn["risk"]]


    with st.container():
        col1, col2, col3, col4 = st.columns([3,1,1,1])

        col1.write(f"{color} {txn['text']}")
        col2.write(f"{int(txn['amount']):,}")
        col3.write(f"{txn['score']}")

        #### explain button

        explain_pressed = col4.button("Explain",key=f"btn_{txn['id']}")

        if explain_pressed:
            with st.spinner("Analyzing...."):
                prompt = f"""

You are a fraud Analyst.

Transaction:
{txn}

Risk Level:
{txn['risk']}

Fraud Score:
{txn['score']}

Instructions:

- if risk is LOW -> say transacxtion appears safe
- if risk is MEDIUM -> explain concerns
- if risk is HIGH -> explain reasons and recommend actions

Output:
- Summary
- Key Signals
- Recommend Action ( must align with risk level)

"""
            explanation = ask_llm(prompt)
            st.session_state.explanations[txn["id"]] = explanation

            ### show explanation if it exist

            if txn["id"] in st.session_state.explanations:
                st.info(st.session_state.explanations[txn["id"]])



