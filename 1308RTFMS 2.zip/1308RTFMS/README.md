### GOAL

Live transaction
fraud risk
HITL
transaction history
AI based
Streamlit dashboard


#### Architecture

Transaction Engine ---> Langgraph & Langchain---> Risk Scoring ---> High Risk ---> HITL
                                   store ----> UI ( LLM Explain )



#### Execution steps

python -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python -m streamlit run app.py