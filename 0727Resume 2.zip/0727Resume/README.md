#### ATS....

### UI Interface - Streamlit...UI

### vector database - chromadb

### embedding model --- gemini...gemini-embedding-001

### storing secret.... .env

structure of code

- .env
- resume_processor.py ( app logic )
- app.py ( UI Interface )
- requirements.txt for packages that need to be installed



### steps to execute

### change the API key in .env file

1> initialize virtual environment

python -m venv venv
source venv/bin/activate ( mac)
venv\scripts\activate ( windows )

2> install packages

pip install -r requirements.txt

3> run the code

python -m streamlit run app.py