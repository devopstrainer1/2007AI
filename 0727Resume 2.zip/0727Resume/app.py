#### UI interace....streamlit

import streamlit as st
import os

from resume_processor import load_resume, analyze_resume, store_to_vectorstore, run_self_query

st.set_page_config(page_title="AI Resume Screener")
st.title("ATS System")
st.markdown("Upload resume and analyze it using AI")

job_desc = st.text_area("Enter Job Description")

uploaded_file = st.file_uploader("Upload Resume (PDF, DOCX, TXT)", type=["pdf","docx","txt"])

if st.button("Analyze & Store") and uploaded_file and job_desc:
    with open(uploaded_file.name, "wb") as f:
        f.write(uploaded_file.getbuffer())
    with st.spinner("Loading Resume....."):
        docs = load_resume(uploaded_file.name)
        report = analyze_resume(docs, job_desc)

        store_to_vectorstore(docs)
        st.success("Resume Anakyzed and stored successfully")

        st.write(report)

    st.download_button("Download Report", report, file_name="resume_analysis.txt")


#### ADDING vector db search functionality

st.divider()

query = st.text_input("Enter your query here....")

if st.button("Search Resumes") and query:
    with st.spinner("Searching...."):
        results = run_self_query(query)
        if results:
            for i, res in enumerate(results, 1):
                st.markdown(f"***Result {i}:***")
                st.write(res["text"])
        else:
            st.warning("no matches found")







