### application logic for ATS
from dotenv import load_dotenv
import os

from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader, TextLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_classic.chains import LLMChain
from langchain_chroma import Chroma


#### retrieve LLM Keys


load_dotenv()
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")

os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

### LLM & embedding model


embedding = GoogleGenerativeAIEmbeddings(
    model="models/gemini-embedding-001"
)

llm = ChatGoogleGenerativeAI(
    model="gemini-flash-latest", 
    temperature=0.3
)


### load resume

def load_resume(resume_path):
    if resume_path.lower().endswith(".pdf"):
        loader = PyPDFLoader(resume_path)
    elif resume_path.lower().endswith(".docx"):
        loader = Docx2txtLoader(resume_path)
    elif resume_path.lower().endswith(".txt"):
        loader = TextLoader(resume_path, encoding="utf-8")
    else:
        raise ValueError("Unsupported file format.")
    return loader.load()

def analyze_resume(docs, job_description):

    full_resume = "\n\n".join([doc.page_content for doc in docs])

    prompt = f"""

You are an ATS, compare the resume with job description. Analyze in brief and give below details in bullet points only:-

- Fit Score (0-100)
- Top 5 matching skills
- Missing Important skills
- One line verdict ( yes/no )

Job_Description: {job_description}

Resume: {full_resume}

"""
    ### LLM chain need to be worked on
    response = llm.invoke(prompt)
    content =  response.content

    if isinstance(content, str):
        return content.strip()

    if isinstance(content, list):
        return "\n".join(
            item.get("text", "") if isinstance(item, dict) else str(item)
            for item in content
        ).strip()
    return str(content)
### store output in vector database


def store_to_vectorstore(docs, persist_directory="chroma_store"):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )

    chunks = splitter.split_documents(docs)

    texts = [chunk.page_content for chunk in chunks]

#### optional argument, but really important
    metadatas =[{"source": f"chunk_{i}"} for i in range(len(texts))]


    vectorstore = Chroma.from_texts(
        texts=texts,
        embedding=embedding,
        metadatas=metadatas,
        persist_directory=persist_directory
    )

    #vectorstore.persist()

    return vectorstore

### query vector database


def run_self_query(query, persist_directory="chroma_store"):

    vectorstore = Chroma(persist_directory="chroma_store", embedding_function=embedding)

###mmr - maximal marginal relevance.....search_type....similarity & mmr
    retriever = vectorstore.as_retriever(
        search_kwargs={"k": 5},
        search_type="mmr")

    docs = retriever.invoke(query)

    context = "\n\n".join([doc.page_content for doc in docs])

    prompt = f"""
Answer the query based on resume content define below only:

Query:
{query}

Resume Context:
{context}

"""
    result = llm.invoke(prompt)
    return result.content