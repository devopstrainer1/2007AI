### GOAL

Live transaction
fraud risk
HITL
transaction history
AI based
Streamlit dashboard


#### Architecture

Transaction Engine ---> Langgraph & Langchain---> Risk Scoring ---> High Risk ---> HITL
                                   store ----> UI ( LLM Explain )